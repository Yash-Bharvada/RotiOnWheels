# Responsive failure patterns and fixes

Check each inventory item against these categories. Not exhaustive — but covers the large majority of what actually breaks on small screens.

## Layout & sizing
- **Fixed pixel widths/heights** on containers (`width: 600px`) instead of fluid units (`max-width: 600px; width: 100%`, `%`, `rem`, or a fluid `clamp()`).
- **Missing `flex-wrap: wrap`** on flex rows that assume enough horizontal space — causes items to be squeezed or overflow instead of stacking.
- **Grid templates with fixed column counts** (`grid-template-columns: repeat(4, 1fr)`) that don't collapse — use `auto-fit`/`auto-fill` with `minmax()`, or override the column count in a media query.
- **Fixed-width sidebars alongside fluid content** that together exceed the viewport — stack them at narrow widths instead.
- **Padding/margins that don't scale down**, pushing content into a smaller effective width than intended on small screens.

## Navigation
- **Desktop-only nav with no mobile fallback** — needs a collapsed/hamburger pattern below the relevant breakpoint.
- **Horizontal nav/tab lists that overflow** rather than wrapping, scrolling, or collapsing into a menu.
- **Dropdowns/submenus positioned assuming desktop space** that clip off-screen or extend past the viewport edge on narrow widths.

## Typography
- **Fixed `font-size` in px with no scaling** — prefer `rem`, or `clamp()` for fluid scaling between breakpoints.
- **Long unbreakable strings** (URLs, emails, code) without `overflow-wrap: break-word` or `word-break`, causing horizontal overflow.
- **Line lengths that get too wide or too narrow** relative to viewport at extreme sizes.

## Images & media
- **Images without `max-width: 100%; height: auto;`** — the single most common cause of horizontal overflow.
- **Fixed-dimension `<img>`/`<video>` tags** that don't scale with their container.
- **Background images not using `background-size: cover/contain`** appropriately for narrow viewports.
- **iframes/embeds (maps, videos) with fixed pixel width** — wrap in a responsive container or use percentage/aspect-ratio sizing.

## Tables
- **Wide tables with no strategy for narrow screens** — options: horizontal scroll wrapper (`overflow-x: auto` on a container, not the whole page), or a card-based stacked layout on small screens.
- **Table cells with fixed widths** that don't shrink, forcing overflow even inside a scroll wrapper.

## Forms & inputs
- **Fixed-width inputs/selects** wider than the viewport, or too narrow to be usable once other elements shrink.
- **Multi-column form layouts that don't stack** into a single column on narrow screens.
- **Inline label + input pairs that don't wrap**, cramping both.

## Touch targets & interaction
- **Tap targets under ~44×44px** (buttons, icon buttons, close icons, checkboxes) — too small for reliable touch interaction.
- **Hover-only interactions with no touch/click fallback** (menus or tooltips that only appear on `:hover`).
- **Interactive elements placed too close together**, causing mis-taps.

## Overlays: modals, popovers, tooltips, toasts
- **Fixed pixel widths wider than small viewports**, causing the overlay itself to overflow or get clipped.
- **Positioning that assumes desktop space** (e.g., `left: 50%; margin-left: -300px;` on a 600px-wide modal) — breaks below 600px viewport width.
- **No max-height / internal scroll** on tall content, causing the overlay to extend off-screen vertically with no way to reach action buttons.

## Global / cross-cutting
- **Missing viewport meta tag.**
- **Any single element wider than 100vw** anywhere on the page — the most common root cause of an unwanted page-level horizontal scrollbar. Worth a dedicated sweep after per-component fixes, since one offending element anywhere breaks the whole page.
- **`overflow-x: hidden` used on `body`/`html` to mask overflow** instead of fixing the underlying element — this hides the symptom but silently clips content; treat it as a signal to find and fix the real cause, not a valid fix itself.
