---
name: mobile-responsive-retrofit
description: Systematically makes an existing website fully mobile responsive by inventorying every page and component, then looping through fix → verify-with-a-real-screenshot → next until nothing on the list is left broken. Use this whenever the user asks to make a site "mobile responsive" or "mobile friendly," fix layout issues on phone or tablet, kill horizontal scrolling, fix a nav/menu/table/modal that breaks on small screens, or generally wants an existing React/Vue (or other) site audited and repaired for small screens — even from a single bare prompt like "make this site mobile responsive" with no other detail given. Also use for narrower asks like "fix the checkout page on mobile" or "this table breaks on phone screens," since the same fix-and-verify loop applies to a single component too.
---

# Mobile Responsive Retrofit

## Why this exists

A single "make it responsive" prompt actually hides dozens of independent, unrelated problems scattered across every page and component. Without a system for tracking and re-checking each one, it's easy to do one shallow pass over the obvious stuff (the nav, maybe the hero) and miss the things that only break on one specific page, or to lose track partway through a big codebase and quietly stop. This skill turns "make it responsive" into a closed loop: inventory everything → fix one thing → *prove* it's fixed with an actual screenshot at real breakpoints → move to the next → don't stop until the list is empty.

The core discipline is: **never mark something done from reading the CSS alone.** Responsive bugs are often invisible in the code and only show up when the page is actually rendered at a given width (a flex row that only overflows between 700–900px, a dropdown that's fine until the viewport gets narrow enough that it clips off-screen). Rendering and screenshotting at each breakpoint is what makes this reliable instead of cosmetic.

## Phase 0: Scope the site

1. **Find the project's own breakpoints first.** Check `tailwind.config.*`, CSS custom properties, a theme file, styled-components breakpoints, or existing `@media` queries. If the project already has a set of breakpoints, use those — don't introduce a competing set. Otherwise default to four: **375px** (small phone), **768px** (tablet / phone landscape), **1024px** (small laptop / tablet landscape), **1440px** (desktop).

2. **Build the inventory.** List every route/page (check the router config) and every reusable component under `src/components`, `src/pages`, `src/views`, or equivalent. This inventory is what the whole task is graded against — nothing is "done" until every item on it is checked off. Include modals, dropdowns, and other conditionally-rendered UI even though they won't show up on a plain page load.

3. **Externalize the checklist.** Write the inventory to a markdown file in the repo, e.g. `RESPONSIVE_AUDIT.md`, with one checkbox per page/component. This is the single most important habit here: the task is broad enough that without a persistent, on-disk checklist it's easy to silently drift off course or stop halfway through and call it done. Keep this file updated as you go — it's both your working memory across a long task and the user's evidence of real progress.

## Phase 1: Baseline before touching any code

Start the dev server if it isn't already running. Then, using the browser tool available in your environment, visit every item in the inventory at every breakpoint and take a screenshot *before* changing anything.

This baseline matters for two reasons: it's what you diff against after each fix, and it frequently surfaces breakage that isn't obvious from reading the code — a card grid that only collapses badly at 768–900px is a common example of something nobody catches by eyeballing the JSX. While you're at it, write down concrete, specific problems per screenshot (horizontal scrollbar present, two elements overlapping, text overflowing its box, nav not collapsing, tap targets that look under ~44px, a modal wider than the viewport) rather than a vague "looks off." Save each screenshot into an artifacts folder, organized by page and breakpoint, so a before/after comparison is trivial later.

## Phase 2: The core loop — fix, verify, next

Work through the inventory file in order. For each item:

1. Read its markup and styles.
2. Check it against the failure patterns in `references/responsive-checklist.md` (fixed pixel widths, non-fluid images, missing `flex-wrap`, a desktop-only nav, absolutely-positioned elements that go off-screen, unstacked tables, and so on).
3. Apply the fix using the project's *existing* styling approach — don't introduce Tailwind into a styled-components project, or a CSS-in-JS pattern into a plain-CSS one. Match what's already there.
4. Reload the page in the browser tool at every breakpoint and take a fresh screenshot.
5. Compare against the baseline and against the checklist criteria. If any breakpoint still shows a problem, the item isn't done — fix again and re-screenshot. Don't advance to the next item until the current one is clean at every breakpoint. This is what makes the process actually converge instead of skimming everything once.
6. Check the box for that item in `RESPONSIVE_AUDIT.md`, with a one-line note of what changed.

If you discover a new component mid-way (a modal that only renders from one specific page, say), add it to the inventory rather than skip it — the goal is that nothing gets missed because it wasn't visible on the first pass.

Keep going until every item in the inventory is checked off. On a large site this loop may run for a long time and touch dozens of files — that's expected; the checklist file is what keeps it from losing the thread.

## Phase 3: Cross-cutting pass

A few things don't show up as a single component and are worth checking once the per-item loop is done:

- **Global overflow-x** — does *any* page produce a horizontal scrollbar at any breakpoint? A single element blowing out the viewport width somewhere is one of the most common leftover bugs after a component-by-component pass.
- **Viewport meta tag** is present (`<meta name="viewport" content="width=device-width, initial-scale=1">`).
- **Breakpoint consistency** — did the per-component fixes converge on the project's real breakpoints, or did something invent its own one-off value along the way?
- **Font scaling and tap-target sizing**, site-wide, not just on the pages that were flagged individually.

## Phase 4: Final report

Summarize what changed, page by page, pairing each with its before/after screenshots from the artifacts folder. Confirm `RESPONSIVE_AUDIT.md` shows everything checked off, and explicitly call out anything intentionally left alone (an internal admin page nobody views on mobile, say) rather than letting it look like an oversight.

## Notes for React / Vue codebases

- Prefer fixing at the shared/reusable component level over patching every page that renders it. If a `Card` or `Table` component is broken, fixing it once fixes every page that uses it — reflect that as multiple checked-off inventory items, since it genuinely does fix multiple pages.
- Watch for CSS-in-JS or utility classes driven by JS-based viewport checks (e.g. `useMediaQuery`, `window.matchMedia`). These won't show up from reading CSS alone and need actual browser verification.
- Check that component libraries (MUI, Ant Design, Chakra, shadcn/ui, etc.) are actually using their built-in responsive props/breakpoints rather than being wrapped in a fixed-width container that defeats them.

For the full list of concrete failure patterns and fixes to check each item against, see `references/responsive-checklist.md`.
